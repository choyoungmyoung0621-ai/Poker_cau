// Server-authoritative blackjack against a shared dealer. All chip amounts are integer virtual chips.
// Rules: 6 decks; dealer stands on soft 17; blackjack pays 3:2; double after split;
// up to four hands per player; split aces receive exactly one card each; no insurance or surrender.
import {secureIndex, randomHex, sha256, SUITS} from './poker.js';

export const BJ_MIN_BET = 10;
export const BJ_MAX_BET = 200;
export const BJ_TURN_MS = 25_000;
const DECK_COUNT = 6;
const CARD_VALUE = card => { const rank=Number(card.slice(0,-1));return rank===14?11:Math.min(10,rank); };
export function blackjackDeck(){
  return Array.from({length:DECK_COUNT}, () => SUITS.flatMap(s => Array.from({length:13},(_,i)=>`${i+2}${s}`))).flat();
}
export function blackjackShuffle(){
  const cards=blackjackDeck();
  for(let i=cards.length-1;i>0;i--){const j=secureIndex(i+1);[cards[i],cards[j]]=[cards[j],cards[i]];}
  return cards;
}
export function blackjackScore(cards){
  let total=0,aces=0;
  for(const c of cards){const rank=Number(c.slice(0,-1));total+=rank===14?11:Math.min(rank,10);if(rank===14)aces++;}
  let soft=aces;
  while(total>21 && soft){total-=10;soft--;}
  return {total,soft:soft>0,bust:total>21,blackjack:cards.length===2&&total===21};
}
export function makeBlackjackPlayer(data,seat){
  return {id:data.id,auth:data.auth,name:data.name,seat,chips:1000,nextBet:20,inRound:false,hands:[],ops:[]};
}
export function makeBlackjackGame(code,owner){
  return {mode:'blackjack',code,players:[makeBlackjackPlayer(owner,0)],hostId:owner.id,
    stage:'lobby',hand:0,shoe:[],cursor:0,nonce:null,commit:null,proof:null,
    dealerCards:[],dealerIndices:[],playerIndices:{},turnId:null,handIndex:null,deadline:null,
    result:null,chat:[],history:[],version:0,lastUpdate:Date.now()};
}
export function blackjackSetBet(g,pid,amount){
  if(!['lobby','result'].includes(g.stage))throw Error('게임이 진행 중에는 다음 판 베팅을 바꿀 수 없어요.');
  const p=g.players.find(p=>p.id===pid);if(!p)throw Error('플레이어를 찾을 수 없어요.');
  if(!Number.isSafeInteger(amount) || amount<0 || amount>BJ_MAX_BET || amount%10!==0 || amount>p.chips || (amount!==0&&amount<BJ_MIN_BET))
    throw Error('베팅은 0(관전) 또는 보유 칩 이내의 10~200칩(10칩 단위)만 가능해요.');
  p.nextBet=amount;
}
function draw(g){
  if(g.cursor>=g.shoe.length)throw Error('카드가 부족해 게임을 진행할 수 없어요.');
  const index=g.cursor++;return {card:g.shoe[index],index};
}
function dealToPlayer(g,p,h){
  const {card,index}=draw(g);h.cards.push(card);h.indices.push(index);
  if(!g.playerIndices[p.id])g.playerIndices[p.id]=[];
  g.playerIndices[p.id].push(index);
}
function dealToDealer(g){const {card,index}=draw(g);g.dealerCards.push(card);g.dealerIndices.push(index);}
const seated=g=>[...g.players].sort((a,b)=>a.seat-b.seat);
const playingHands=g=>seated(g).flatMap(p=>p.hands.map((h,i)=>({p,h,i})).filter(x=>x.h.status==='playing'));

export async function blackjackStart(g,onlineIds){
  if(!['lobby','result'].includes(g.stage))throw Error('이미 진행 중인 라운드입니다.');
  const active=seated(g).filter(p=>onlineIds.has(p.id)&&p.chips>=BJ_MIN_BET&&p.nextBet>=BJ_MIN_BET&&p.nextBet<=p.chips);
  if(!active.length)throw Error('베팅을 선택하고 접속한 플레이어가 한 명 이상 필요해요.');
  const deck=blackjackShuffle(),nonce=randomHex(24),commit=await sha256(`${nonce}:${deck.join(',')}`);
  g.hand++;g.stage='playing';g.shoe=deck;g.cursor=0;g.nonce=nonce;g.commit=commit;g.proof=null;
  g.dealerCards=[];g.dealerIndices=[];g.playerIndices={};g.result=null;g.turnId=null;g.handIndex=null;g.deadline=null;
  const activeIds=new Set(active.map(p=>p.id));
  for(const p of g.players){
    p.inRound=activeIds.has(p.id);p.hands=[];p.ops=[];
    if(p.inRound){p.chips-=p.nextBet;p.hands=[{cards:[],indices:[],wager:p.nextBet,status:'playing',split:false,splitAces:false,doubled:false}];}
  }
  for(const p of active)dealToPlayer(g,p,p.hands[0]);
  dealToDealer(g);
  for(const p of active)dealToPlayer(g,p,p.hands[0]);
  dealToDealer(g);
  for(const p of active){
    if(blackjackScore(p.hands[0].cards).blackjack)p.hands[0].status='blackjack';
  }
  if(blackjackScore(g.dealerCards).blackjack){blackjackSettle(g,true);return;}
  blackjackAdvance(g);
}

export function blackjackLegal(g,pid){
  if(g.stage!=='playing'||g.turnId!==pid)return null;
  const p=g.players.find(p=>p.id===pid),h=p?.hands[g.handIndex];
  if(!p||!h||h.status!=='playing')return null;
  const pair=h.cards.length===2 && CARD_VALUE(h.cards[0])===CARD_VALUE(h.cards[1]);
  return {handIndex:g.handIndex,canHit:!h.splitAces,canStand:true,
    canDouble:h.cards.length===2&&!h.splitAces&&p.chips>=h.wager,
    canSplit:pair&&!h.splitAces&&p.hands.length<4&&p.chips>=h.wager};
}
export function blackjackAction(g,pid,action){
  const legal=blackjackLegal(g,pid);if(!legal)throw Error('지금은 행동할 차례가 아니에요.');
  const p=g.players.find(x=>x.id===pid),h=p.hands[g.handIndex];
  if(action==='hit'){
    if(!legal.canHit)throw Error('현재 손패에서는 카드를 더 받을 수 없어요.');
    dealToPlayer(g,p,h);
    const score=blackjackScore(h.cards);
    if(score.bust)h.status='bust';else if(score.total===21)h.status='stood';
  }else if(action==='stand')h.status='stood';
  else if(action==='double'){
    if(!legal.canDouble)throw Error('더블 다운을 할 수 없어요.');
    p.chips-=h.wager;h.wager*=2;h.doubled=true;
    dealToPlayer(g,p,h);
    h.status=blackjackScore(h.cards).bust?'bust':'stood';
  }else if(action==='split'){
    if(!legal.canSplit)throw Error('스플릿을 할 수 없어요.');
    p.chips-=h.wager;
    const [first,second]=h.cards,[firstIndex,secondIndex]=h.indices;
    const aces=Number(first.slice(0,-1))===14;
    h.cards=[first];h.indices=[firstIndex];h.split=true;h.splitAces=aces;
    h.status='playing';
    const other={cards:[second],indices:[secondIndex],wager:h.wager,status:'playing',split:true,splitAces:aces,doubled:false};
    p.hands.splice(g.handIndex+1,0,other);
    dealToPlayer(g,p,h);dealToPlayer(g,p,other);
    if(aces){h.status='stood';other.status='stood';}
    else {
      if(blackjackScore(h.cards).total===21)h.status='stood';
      if(blackjackScore(other.cards).total===21)other.status='stood';
    }
  }else throw Error('지원하지 않는 행동이에요.');
  blackjackAdvance(g);
}

export function blackjackAdvance(g){
  const next=playingHands(g)[0];
  if(next){g.turnId=next.p.id;g.handIndex=next.i;g.deadline=Date.now()+BJ_TURN_MS;return;}
  // Dealer never needs to draw if every non-blackjack hand has busted.
  const competing=g.players.some(p=>p.inRound&&p.hands.some(h=>h.status!=='bust'&&h.status!=='blackjack'));
  if(competing){
    while(true){
      const s=blackjackScore(g.dealerCards);
      if(s.total>=17)break; // Stand on both hard 17 and soft 17.
      dealToDealer(g);
    }
  }
  blackjackSettle(g,false);
}

export function blackjackSettle(g,dealerNatural=false){
  const dealer=blackjackScore(g.dealerCards);const results=[];
  for(const p of g.players){
    if(!p.inRound)continue;
    const hands=p.hands.map((h,index)=>{
      const score=blackjackScore(h.cards),natural=h.status==='blackjack';
      let outcome,payout=0;
      if(dealerNatural){outcome=natural?'push':'lose';payout=natural?h.wager:0;}
      else if(natural){outcome='blackjack';payout=h.wager*5/2;}
      else if(score.bust){outcome='bust';payout=0;}
      else if(dealer.bust || score.total>dealer.total){outcome='win';payout=h.wager*2;}
      else if(score.total===dealer.total){outcome='push';payout=h.wager;}
      else {outcome='lose';payout=0;}
      if(!Number.isSafeInteger(payout))throw Error('정산 금액 계산 오류');
      p.chips+=payout;
      return {index,cards:[...h.cards],wager:h.wager,outcome,payout,total:score.total};
    });
    results.push({id:p.id,name:p.name,hands});
    if(p.chips<BJ_MIN_BET)p.nextBet=0;
    else if(p.nextBet>p.chips)p.nextBet=Math.min(BJ_MAX_BET,Math.floor(p.chips/10)*10);
  }
  g.result={dealerCards:[...g.dealerCards],dealerTotal:dealer.total,dealerNatural,players:results};
  g.proof={nonce:g.nonce,commit:g.commit,deck:g.shoe,playerIndices:g.playerIndices,dealerIndices:g.dealerIndices};
  g.stage='result';g.turnId=null;g.handIndex=null;g.deadline=null;
  g.history.unshift(`라운드 #${g.hand}: ${results.map(r=>r.name+' '+r.hands.map(h=>h.outcome).join('/')).join(', ')}`);
  g.history=g.history.slice(0,20);
}

export function blackjackView(g,viewerId,onlineIds){
  const me=g.players.find(p=>p.id===viewerId);
  const finished=g.stage==='result';
  return {type:'state',mode:'blackjack',now:Date.now(),version:g.version,code:g.code,hand:g.hand,stage:g.stage,
    hostId:g.hostId,turnId:g.turnId,handIndex:g.handIndex,deadline:g.deadline,
    dealerCards:finished?g.dealerCards:[g.dealerCards[0]||null,...(g.dealerCards.length>1?['back']:[])],
    dealerTotal:finished?blackjackScore(g.dealerCards).total:null,
    players:g.players.map(p=>({id:p.id,name:p.name,seat:p.seat,chips:p.chips,nextBet:p.nextBet,inRound:p.inRound,
      online:onlineIds.has(p.id),hands:p.hands.map(h=>({cards:h.cards,wager:h.wager,status:h.status,doubled:h.doubled,score:blackjackScore(h.cards).total}))})),
    me:{id:me.id,name:me.name,seat:me.seat,legal:blackjackLegal(g,viewerId)},
    result:g.result,commit:g.commit,proof:finished?g.proof:null,chat:g.chat.slice(-25),history:g.history.slice(0,12)};
}
